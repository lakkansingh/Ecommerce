package com.e.ecommerce.model;

public class BookAppointmentModelResponse {
}
