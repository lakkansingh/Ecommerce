package com.e.ecommerce.model;

public class ImageSrcModel {
    /*
    "image": {
        "src": "http://localhost/femdev/wp-content/uploads/2018/12/slider-2-1.png"
    }
*/
    private String src;

    public ImageSrcModel() {

    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }
}
